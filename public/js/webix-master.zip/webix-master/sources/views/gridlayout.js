
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"gridlayout", defaults:{
	template:"GPL version doesn't support gridlayout <br> You need Webix PRO"
}}, template.view);