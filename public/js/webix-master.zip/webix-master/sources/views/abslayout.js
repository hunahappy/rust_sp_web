
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"abslayout", defaults:{
	template:"GPL version doesn't support abslayout <br> You need Webix PRO"
}}, template.view);