
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"gridsuggest", defaults:{
	template:"GPL version doesn't support gridsuggest <br> You need Webix PRO"
}}, template.view);