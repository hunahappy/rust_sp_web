
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"excelviewer", defaults:{
	template:"GPL version doesn't support excelviewer <br> You need Webix PRO"
}}, template.view);