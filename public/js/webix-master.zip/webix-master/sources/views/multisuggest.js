
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"multisuggest", defaults:{
	template:"GPL version doesn't support multisuggest <br> You need Webix PRO"
}}, template.view);