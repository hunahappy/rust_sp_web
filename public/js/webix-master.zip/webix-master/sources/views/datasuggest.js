
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"datasuggest", defaults:{
	template:"GPL version doesn't support datasuggest <br> You need Webix PRO"
}}, template.view);