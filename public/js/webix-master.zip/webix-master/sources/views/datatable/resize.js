import {pos, addCss, denySelect, removeCss, allowSelect, offset, posRelative, create, remove} from "../../webix/html";
import {delay, isUndefined} from "../../webix/helpers";
import {$$, ui} from "../../ui/core";
import {_event, event, eventRemove} from "../../webix/htmlevents";

//indirect import
import "../resizearea";

const Mixin = {
	_rs_init_flag: true,
	resizeRow_setter:function(value){
		this._settings.scrollAlignY = false;
		this._settings.fixedRowHeight = false;
		this._applyResizeHandlers(value);
		return value;
	},
	resizeColumn_setter:function(value){
		this._applyResizeHandlers(value);
		return value;
	},
	_applyResizeHandlers: function(value) {
		if (!this._rs_init_flag) return;
    
		if (value) {
			if (value.icon) {
				_event(this._header, "pointerdown", e => this._handleResizerPointerDown(e, "header"));
				_event(this._footer, "pointerdown", e => this._handleResizerPointerDown(e, "footer"));

				this._renderResizers = true;
			} else {
				// backward compatibility
				_event(this._viewobj, "mousemove", e => this._rs_move(e));
				_event(this._viewobj, "mousedown", e => this._rs_down(e));
				_event(this._viewobj, "mouseup", () => this._rs_up());
			}

			this._rs_init_flag = false;
		}
	},
	_handleResizerPointerDown: function(e, section) {
		const resizerElement = this._findResizerElement(e.target);
		if (!resizerElement) return;

		let columnIndex = this._getColumnIndexFromResizer(resizerElement);
		if (columnIndex === null) return;

		e.preventDefault();
		e.stopPropagation();

		const column = this._columns[columnIndex];
		if (!column || column.resize === false) return;

		const liveResize = isUndefined(this._settings.resizeColumn.live) ? true : !!this._settings.resizeColumn.live;

		this._activeResizer = {
			columnIndex,
			section,
			startX: e.clientX,
			startWidth: column.width,
			resizerElement,
			updateLoop: false,
			lastEvent: null
		};

		// better tracking for edge cases (iframes)
		if (this._viewobj.setPointerCapture) this._viewobj.setPointerCapture(e.pointerId);

		// create a resize marker
		// not using resizearea due to pointer events (resizearea uses mouse/touch events)
		if (!liveResize) {
			const marker = create("div", { class: "webix_resize_marker" });
			this._viewobj.appendChild(marker);
			this._activeResizer.marker = marker;

			const resizerRect = resizerElement.getBoundingClientRect();
			const containerRect = this._viewobj.getBoundingClientRect();
			const markerStart = containerRect.left + (resizerRect.left - containerRect.left) + (resizerRect.width / 2);

			this._updateMarkerPos(markerStart);
			this._activeResizer.markerStart = markerStart;
		}

		this._resizerMoveEv = event(document, "pointermove", e => this._handleResizerPointerMove(e, liveResize));
		this._resizerUpEv = event(document, "pointerup", e => this._handleResizerPointerUp(e, liveResize));

		this._viewobj.style.cursor = "col-resize";

		addCss(document.body, "webix_noselect");
		denySelect();
	},
	_updateMarkerPos(pos) {
		const rect = this._viewobj.getBoundingClientRect();
		this._activeResizer.marker.style.left = (pos - rect.left) + "px";
	},
	_handleResizerPointerMove: function(e, liveResize) {
		if (!this._activeResizer) return;

		if (liveResize) {
			this._activeResizer.lastEvent = { clientX: e.clientX, clientY: e.clientY };

			if (!this._activeResizer.updateLoop) {
				this._activeResizer.updateLoop = true;
				this._startResizeUpdateLoop();
			}
		} else {
			const { startX, markerStart } = this._activeResizer;
			const delta = e.clientX - startX;
			this._updateMarkerPos(markerStart + delta);
		}
	},
	_handleResizerPointerUp: function(e, liveResize) {
		if (!this._activeResizer) return;
		if (this._viewobj.releasePointerCapture) this._viewobj.releasePointerCapture(e.pointerId);

		if (liveResize) {
			this._activeResizer.updateLoop = false;
		} else {
			remove(this._activeResizer.marker);
		}

		window.requestAnimationFrame(() => this._applyResize(e.clientX, true));
	},
	_startResizeUpdateLoop: function() {
		if (!this._activeResizer || !this._activeResizer.updateLoop) return;

		const lastEvent = this._activeResizer.lastEvent;
		if (lastEvent) this._applyResize(lastEvent.clientX, false);

		window.requestAnimationFrame(() => this._startResizeUpdateLoop());
	},
	_applyResize: function(currentX, isFinalized) {
		if (!this._activeResizer) return;

		const newWidth = this._calculateResizeWidth(currentX);
		const columnIndex = this._activeResizer.columnIndex;
		const column = this._columns[columnIndex];

		if (!column || newWidth === null) return;

		delete column.fillspace;
		delete column.adjust;

		if (isFinalized) this._activeResizer = null;

		this._setColumnWidth(columnIndex, newWidth, true, true);
		this._updateColsSizeSettings();

		if (isFinalized) {
			eventRemove(this._resizerMoveEv);
			eventRemove(this._resizerUpEv);

			this._viewobj.style.cursor = "";

			removeCss(document.body, "webix_noselect");
			allowSelect();
		}
	},
	_calculateResizeWidth: function(currentX) {
		if (!this._activeResizer) return null;

		const { startX, columnIndex, startWidth } = this._activeResizer;
		const deltaX = currentX - startX;
		const isRightSplit = this._settings.rightSplit && columnIndex >= this._rightSplit;
		const adjustedDelta = isRightSplit ? -deltaX : deltaX;
    
		return Math.max(20, startWidth + adjustedDelta);
	},
	_getColumnIndexFromResizer: function(resizer) {
		let columnAttr = resizer.getAttribute("data-col");
		if (columnAttr !== null) {
			return parseInt(columnAttr, 10);
		}

		let node = resizer;
		while (node && node !== this._viewobj) {
			columnAttr = node.getAttribute("data-col");
			if (columnAttr !== null) {
				return parseInt(columnAttr, 10);
			}
			node = node.parentElement;
		}

		return null;
	},
	_findResizerElement: function(target) {
		let node = target;
		while (node && node !== this._viewobj) {
			if (node.classList && node.classList.contains("webix_resizer")) {
				return node;
			}
        
			node = node.parentElement;
		}
		return null;
	},
	_rs_down:function(e){
		// do not listen to mousedown of subview on master
		if (!this._rs_ready || (this._settings.subview && this != $$(e.target))) return;
		this._rs_process = [pos(e), this._rs_ready];
		addCss(document.body,"webix_noselect");
		denySelect();
	},
	_rs_up:function(){
		this._rs_process = false;
		removeCss(document.body,"webix_noselect");
		allowSelect();
	},
	_rs_start:function(){
		if (this._rs_progress) return;

		const [dir, size, node, cell] = this._rs_process[1];
		let eventPos = this._rs_process[0];
		let start;

		if (dir == "x"){
			start = offset(node).x + size - offset(this._body).x;
			eventPos = eventPos.x;
		} else {
			start = offset(node).y + size - offset(this._body).y + this._header_height;
			eventPos = eventPos.y;
		}

		this._rs_progress = [dir, cell, start];
		const resize = new ui.resizearea({
			container:this._viewobj,
			eventPos,
			start,
			dir,
			cursor:(dir == "x"?"col":"row")+"-resize"
		});
		resize.attachEvent("onResizeEnd", pos => this._rs_end(pos));

		this._rs_ready = false;
	},
	_rs_end:function(result){
		if (this._rs_progress){
			const cell = this._rs_progress[1];
			let newsize = result - this._rs_progress[2];

			if (this._rs_progress[0] == "x"){
				//in case of right split - different sizing logic applied
				if (this._settings.rightSplit && cell.cind >= this._rightSplit){
					newsize *= -1;
				}
				
				const col = this._columns[cell.cind];
				const oldwidth = col.width;

				delete col.fillspace;
				delete col.adjust;

				this._setColumnWidth(cell.cind, oldwidth + newsize, true, true);
				this._updateColsSizeSettings();
			} else {
				const id = this.getIdByIndex(cell.rind);
				const oldheight = this._getRowHeight(this.getItem(id));
				this.setRowHeight(id, oldheight + newsize);
			}
			this._rs_up();
		}
		this._rs_progress = null;
	},
	_rs_move:function(e){
		if (this._rs_ready && this._rs_process)
			return this._rs_start();
		this._rs_ready = false;

		let mode = false;
		let node = e.target;

		if(this._viewobj.contains(node)){
			const config = this._settings;
			let in_body, in_header;

			while (!(node == this._viewobj || in_body || in_header)){
				//we can't use node.className because there can be SVG (in SVG it is an SVGAnimatedString object)
				const element_class = node.getAttribute("class")||"";
				in_body = element_class.indexOf("webix_cell") != -1;
				in_header = element_class.indexOf("webix_hcell") != -1;

				if(!(in_body || in_header))
					node = node.parentElement;
			}

			//ignore resize in case of drag-n-drop enabled
			if (in_body && config.drag) return this._mark_resize(mode);

			
			if (in_body || in_header){
				const pos = posRelative(e);
				const cell = this._locate(node);

				mode = this._is_column_rs(cell, pos, node, config.resizeColumn, in_body)
					|| (in_body && this._is_row_rs(cell, pos, node, config.resizeRow));
			}
		}

		//mark or unmark resizing ready state
		this._mark_resize(mode);
	},
	_is_column_rs:function(cell, pos, node, rColumn, in_body){
		// if resize is only within the header
		if (!rColumn || (in_body && rColumn.headerOnly)) return false;

		const dx = node.offsetWidth;
		rColumn = rColumn.size ? rColumn.size : 3;

		let col, config;
		if (pos.x < rColumn){
			if (cell.cind < this._rightSplit)
				cell.cind -= (cell.span||1);
			col = this._columns[cell.cind];
			config = ["x", 0, node, cell];
		}
		else if (dx-pos.x < rColumn+1){
			if (this._settings.rightSplit && cell.cind+1 >= this._rightSplit)
				cell.cind++;
			if (!this._settings.rightSplit || cell.cind < this._columns.length){
				col = this._columns[cell.cind];
				config = ["x", dx, node, cell];
			}
		}

		if (col && col.resize !== false){
			this._rs_ready = config;
			return "col-resize";
		}
		return false;
	},
	_is_row_rs:function(cell, pos, node, rRow){
		// if resize is only within the first column
		if (!rRow || (rRow.headerOnly && cell.cind > 0)) return false;

		// block selection in progress
		if (this._bs_progress) return false;

		const dy = node.offsetHeight;
		rRow = rRow.size ? rRow.size : 3;

		if (pos.y < rRow){
			if (cell.rind > 0){			// avoid resize header border
				cell.rind--;
				this._rs_ready = ["y", 0, node, cell];
			}
		}
		else if (dy-pos.y < rRow+1)
			this._rs_ready = ["y", dy, node, cell];

		return this._rs_ready ? "row-resize" : false;
	},
	_mark_resize:function(mode){
		if (this._cursor_timer) window.clearTimeout(this._cursor_timer);
		this._cursor_timer = delay(this._mark_resize_ready, this, [mode], mode?100:0);
	},
	_mark_resize_ready:function(mode){
		if (this._last_cursor_mode != mode){
			this._last_cursor_mode = mode;
			this._viewobj.style.cursor = mode || "";
		}
	}
};

export default Mixin;