
import {protoUI} from "../ui/core";
import template from "../views/template";

protoUI({ name:"filter", defaults:{
	template:"GPL version doesn't support filter <br> You need Webix PRO"
}}, template.view);